package com.capg.mms.model;

public enum SeatStatus {

	AVAILABLE,BOOKED,BLOCKED;
}