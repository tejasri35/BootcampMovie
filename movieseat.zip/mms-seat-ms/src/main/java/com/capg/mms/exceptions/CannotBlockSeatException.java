package com.capg.mms.exceptions;

public class CannotBlockSeatException extends RuntimeException {

	public CannotBlockSeatException(String message) {
		super(message);
	}
}
