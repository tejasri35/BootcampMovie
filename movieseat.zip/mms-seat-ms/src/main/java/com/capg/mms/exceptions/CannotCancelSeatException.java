package com.capg.mms.exceptions;

public class CannotCancelSeatException extends RuntimeException {

	public CannotCancelSeatException(String message) {
		super(message);
	}
}
