package com.capg.mms.exceptions;

public class SeatException extends Exception {

	public SeatException(String message)
	{
		super(message);
	
	}
	public SeatException()
	{
		super();
	}
}


