package com.capg.mms.exceptions;

public class CannotBookSeatException extends RuntimeException {

	public CannotBookSeatException(String message) {
		super(message);
	}
}
