package com.capg.mms;



import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.VerificationCollector;

import com.capg.mms.model.Seat;
import com.capg.mms.repository.ISeatRepository;

import mockit.integration.junit4.JMockit;


@SuppressWarnings("unused")
@RunWith(JMockit.class)
public class SeatServiceTest {
	public VerificationCollector verificationCollector = MockitoJUnit.collector();
	@Mock
    private ISeatRepository seatRepo;
	@Before
	public void setup(){
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public void addSeat() {
		Seat seat=new Seat();
		seat.setSeatId(1284);
		seat.getSeatStatus();
		seat.setSeatPrice(200.00);
		
	}
	@Test
	public void getAllAvailableSeats(){
		List<Seat> seatList = new ArrayList<Seat>();
		seatList.add(new Seat());
		when(seatRepo.findAll()).thenReturn(seatList);
		List<Seat> result = (List<Seat>) seatRepo.findAll();
		assertEquals(1, seatList.size());
	}
}
